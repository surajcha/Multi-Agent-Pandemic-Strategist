import boto3
import uuid
import os
import json

def lambda_handler(event, context):
    try:
        body_str = event.get('body', '{}')
        body = json.loads(body_str)
        if event['requestContext']['http']['method'] == 'OPTIONS':
        # Handle CORS preflight request
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
                },
                'body': json.dumps({'message': 'CORS preflight check passed'})
            }

        input_text = body.get('input_text', None) + ' using information available in LLM by default. Do not ask for any documentation.Use LLM knowledge only. Use <br> in place of numbering the response points'

        # Initialize the Bedrock Agent Runtime client
        bedrock = boto3.client('bedrock-agent-runtime', region_name=os.environ.get("AWS_REGION", "eu-north-1"))

        # Get Agent ID and Alias ID from environment variables
        agent_id = os.environ.get("AGENT_ID", "V68IID10DM")
        agent_alias_id = os.environ.get("AGENT_ALIAS_ID", "1JBQJL6O9B")

        # Generate a unique session ID
        session_id = str(uuid.uuid4())

        # Invoke the Bedrock Agent
        response_stream = bedrock.invoke_agent(
            agentId=agent_id,
            agentAliasId=agent_alias_id,
            sessionId=session_id,
            inputText=input_text
        )

        # Collect the streamed response
        output_text = ""
        for event in response_stream['completion']:
            if 'chunk' in event:
                output_text += event['chunk']['bytes'].decode('utf-8')

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({
                "message": "Lambda executed successfully",
                "output": output_text
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({
                "message": "An error occurred",
                "error": str(e)
            })
        }

